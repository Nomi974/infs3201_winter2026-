require("dotenv").config();

const express = require("express");
const path = require("path");
const crypto = require("crypto");
const { engine } = require("express-handlebars");
const business = require("./business");
const persistence = require("./persistence");

const app = express();

app.engine("hbs", engine({ extname: ".hbs" }));
app.set("view engine", "hbs");
app.set("views", path.join(__dirname, "views"));

app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "public")));

// ============================================================
// SESSION STORE
// In-memory map of sessionToken -> { username, expiresAt }
// ============================================================
const sessions = new Map();

const SESSION_DURATION_MS = 5 * 60 * 1000; // 5 minutes

/**
 * Create a new session for a user and return the session token.
 * @param {string} username
 * @returns {string} session token
 */
function createSession(username) {
  const token = crypto.randomBytes(32).toString("hex");
  sessions.set(token, {
    username: username,
    expiresAt: Date.now() + SESSION_DURATION_MS
  });
  return token;
}

/**
 * Get session data from a token. Returns null if missing or expired.
 * If valid, extends the expiry by another 5 minutes.
 * @param {string} token
 * @returns {{ username: string, expiresAt: number } | null}
 */
function getSession(token) {
  if (!token) return null;
  const session = sessions.get(token);
  if (!session) return null;
  if (Date.now() > session.expiresAt) {
    sessions.delete(token);
    return null;
  }
  // Extend session on every valid access
  session.expiresAt = Date.now() + SESSION_DURATION_MS;
  return session;
}

/**
 * Delete a session by token (logout).
 * @param {string} token
 */
function destroySession(token) {
  sessions.delete(token);
}

// ============================================================
// MIDDLEWARE - Security access log
// Logs every request to the security_log collection.
// ============================================================
app.use(async (req, res, next) => {
  try {
    const token = req.headers.cookie ? parseCookie(req.headers.cookie)["session"] : null;
    const session = getSession(token);
    await persistence.insertSecurityLog({
      timestamp: new Date(),
      username: session ? session.username : "anonymous",
      url: req.originalUrl,
      method: req.method
    });
  } catch (err) {
    // Don't block the request if logging fails
    console.error("Security log error:", err.message);
  }
  next();
});

// ============================================================
// MIDDLEWARE - Auth guard
// Protects all routes except /login and /logout.
// ============================================================
app.use((req, res, next) => {
  const openRoutes = ["/login", "/logout"];
  if (openRoutes.indexOf(req.path) !== -1) return next();

  const token = req.headers.cookie ? parseCookie(req.headers.cookie)["session"] : null;
  const session = getSession(token);

  if (!session) {
    return res.redirect("/login?message=Please+log+in+to+continue.");
  }

  // Attach username to request for use in routes
  req.username = session.username;
  next();
});

/**
 * Parse a raw cookie header string into a key/value object.
 * @param {string} cookieHeader
 * @returns {Object}
 */
function parseCookie(cookieHeader) {
  const result = {};
  const pairs = cookieHeader.split(";");
  let i = 0;
  while (i < pairs.length) {
    const pair = pairs[i].trim();
    const eqIndex = pair.indexOf("=");
    if (eqIndex !== -1) {
      const key = pair.substring(0, eqIndex).trim();
      const value = pair.substring(eqIndex + 1).trim();
      result[key] = value;
    }
    i++;
  }
  return result;
}

// ============================================================
// AUTH ROUTES
// ============================================================

/**
 * Login page.
 */
app.get("/login", (req, res) => {
  const message = req.query.message || null;
  res.render("login", { message });
});

/**
 * Login form submission.
 */
app.post("/login", async (req, res) => {
  const username = (req.body.username || "").trim();
  const password = (req.body.password || "").trim();

  // Hash password with SHA-256 before comparing
  const hashedPassword = crypto.createHash("sha256").update(password).digest("hex");

  const valid = await business.validateLogin(username, hashedPassword);

  if (!valid) {
    return res.redirect("/login?message=Invalid+username+or+password.");
  }

  const token = createSession(username);

  // Set cookie with Max-Age matching session duration
  res.setHeader(
    "Set-Cookie",
    `session=${token}; HttpOnly; Max-Age=${SESSION_DURATION_MS / 1000}; Path=/`
  );

  res.redirect("/");
});

/**
 * Logout: destroy session and clear cookie.
 */
app.get("/logout", (req, res) => {
  const token = req.headers.cookie ? parseCookie(req.headers.cookie)["session"] : null;
  if (token) destroySession(token);

  res.setHeader("Set-Cookie", "session=; HttpOnly; Max-Age=0; Path=/");
  res.redirect("/login?message=You+have+been+logged+out.");
});

// ============================================================
// MAIN ROUTES
// ============================================================

/**
 * Landing page: list all employees.
 */
app.get("/", async (req, res) => {
  const employees = await business.getAllEmployees();
  res.render("home", { employees, username: req.username });
});

/**
 * Employee details page (with sorted shifts).
 */
app.get("/employee/:id", async (req, res) => {
  const pageModel = await business.getEmployeeDetailsPageModel(req.params.id);
  if (!pageModel) return res.status(404).send("Employee not found");
  res.render("employee", { ...pageModel, username: req.username });
});

/**
 * Edit employee form (prefilled).
 */
app.get("/employee/:id/edit", async (req, res) => {
  const emp = await business.getEmployeeById(req.params.id);
  if (!emp) return res.status(404).send("Employee not found");
  res.render("editEmployee", { employee: emp, username: req.username });
});

/**
 * Edit employee form submission with server-side validation + PRG redirect.
 */
app.post("/employee/:id/edit", async (req, res) => {
  const empId = req.params.id;
  const name = (req.body.name || "").trim();
  const phone = (req.body.phone || "").trim();
  const phoneRegex = /^\d{4}-\d{4}$/;

  if (name.length === 0) {
    return res.send("Validation error: Name must not be empty.");
  }
  if (!phoneRegex.test(phone)) {
    return res.send("Validation error: Phone must be in the format 1234-5678.");
  }

  const updated = await business.updateEmployee(empId, name, phone);
  if (!updated) return res.status(404).send("Employee not found");

  res.redirect("/");
});

/**
 * New employee form.
 */
app.get("/employee/new", (req, res) => {
  res.render("newEmployee", { username: req.username });
});

/**
 * New employee form submission.
 */
app.post("/employee/new", async (req, res) => {
  const name = (req.body.name || "").trim();
  const phone = (req.body.phone || "").trim();

  const { error, empId } = await business.createEmployee(name, phone);

  if (error) {
    return res.render("newEmployee", { error, username: req.username });
  }

  res.redirect(`/employee/${empId}`);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Running on http://localhost:${PORT}`));
