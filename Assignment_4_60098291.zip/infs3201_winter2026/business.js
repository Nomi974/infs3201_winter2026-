const { ObjectId } = require("mongodb");
const persistence = require("./persistence");

/**
 * Validate and create a new employee.
 * Returns an error message string if validation fails, otherwise null.
 * @param {string} name
 * @param {string} phone
 * @returns {Promise<{ error: string|null, empId: string|null }>}
 */
async function createEmployee(name, phone) {
  const phoneRegex = /^\d{4}-\d{4}$/;

  if (name.length === 0) {
    return { error: "Name must not be empty.", empId: null };
  }
  if (!phoneRegex.test(phone)) {
    return { error: "Phone must be in the format 1234-5678.", empId: null };
  }

  const empId = await persistence.createEmployee(name, phone);
  return { error: null, empId };
}

/**
 * Get all employees for the landing page.
 * @returns {Promise<Array<Object>>}
 */
async function getAllEmployees() {
  return await persistence.getAllEmployees();
}

/**
 * Get one employee by their ObjectId string from the URL.
 * Returns null if the id is not a valid ObjectId format.
 * @param {string} empId - 24-character hex string from req.params.id
 * @returns {Promise<Object|null>}
 */
async function getEmployeeById(empId) {
  if (!ObjectId.isValid(empId)) return null;
  return await persistence.getEmployeeById(empId);
}

/**
 * Update employee name and phone.
 * @param {string} empId - 24-character hex string from req.params.id
 * @param {string} name
 * @param {string} phone
 * @returns {Promise<boolean>}
 */
async function updateEmployee(empId, name, phone) {
  if (!ObjectId.isValid(empId)) return false;
  return await persistence.updateEmployee(empId, name, phone);
}

/**
 * Convert "HH:mm" to minutes since midnight.
 * @param {string} time
 * @returns {number}
 */
function timeToMinutes(time) {
  const h = parseInt(time.substring(0, 2));
  const m = parseInt(time.substring(3, 5));
  return h * 60 + m;
}

/**
 * Compare two shifts by date then start time.
 * @param {Object} a
 * @param {Object} b
 * @returns {number}
 */
function compareShift(a, b) {
  if (a.date < b.date) return -1;
  if (a.date > b.date) return 1;
  const am = timeToMinutes(a.startTime);
  const bm = timeToMinutes(b.startTime);
  if (am < bm) return -1;
  if (am > bm) return 1;
  return 0;
}

/**
 * Selection sort for shifts array (no Array.sort callback allowed).
 * @param {Array<Object>} shifts
 * @returns {Array<Object>}
 */
function sortShifts(shifts) {
  let i = 0;
  while (i < shifts.length) {
    let minIndex = i;
    let j = i + 1;
    while (j < shifts.length) {
      if (compareShift(shifts[j], shifts[minIndex]) < 0) minIndex = j;
      j++;
    }
    if (minIndex !== i) {
      const tmp = shifts[i];
      shifts[i] = shifts[minIndex];
      shifts[minIndex] = tmp;
    }
    i++;
  }
  return shifts;
}

/**
 * Build the page model for the employee details page.
 * Fetches the employee and their shifts in two DB calls (down from three in A3).
 * @param {string} empId - 24-character hex string from req.params.id
 * @returns {Promise<Object|null>}
 */
async function getEmployeeDetailsPageModel(empId) {
  if (!ObjectId.isValid(empId)) return null;

  const employee = await persistence.getEmployeeById(empId);
  if (!employee) return null;

  // getShiftsByEmployeeId expects a real ObjectId, not a string
  const shifts = await persistence.getShiftsByEmployeeId(employee._id);

  let k = 0;
  while (k < shifts.length) {
    shifts[k].isBeforeNoon = timeToMinutes(shifts[k].startTime) < 12 * 60;
    k++;
  }

  sortShifts(shifts);

  return { employee, shifts };
}

/**
 * Validate login credentials against the users collection.
 * Hashes the provided password with SHA-256 and compares to stored hash.
 * @param {string} username
 * @param {string} hashedPassword - SHA-256 hex string (hashed before calling this)
 * @returns {Promise<boolean>}
 */
async function validateLogin(username, hashedPassword) {
  const user = await persistence.getUserByUsername(username);
  if (!user) return false;
  return user.password === hashedPassword;
}

module.exports = {
  createEmployee,
  getAllEmployees,
  getEmployeeById,
  updateEmployee,
  getEmployeeDetailsPageModel,
  validateLogin
};