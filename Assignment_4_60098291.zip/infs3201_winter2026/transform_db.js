require("dotenv").config();

const { MongoClient, ObjectId } = require("mongodb");

const DB_NAME = "infs3201_winter2026";

let _db = null;

/**
 * Get database singleton.
 * @returns {Promise<import("mongodb").Db>}
 */
async function getDb() {
  if (_db) return _db;
  const client = new MongoClient(process.env.MONGODB_URI);
  await client.connect();
  _db = client.db(DB_NAME);
  return _db;
}

// ============================================================
// STEP 1 - Add empty employees array to every shift document
// ============================================================

/**
 * Adds an empty "employees" array field to every shift that doesn't have one yet.
 * Safe to run multiple times.
 * @returns {Promise<void>}
 */
async function addEmptyEmployeesArrayToShifts() {
  const db = await getDb();
  const result = await db.collection("shifts").updateMany(
    { employees: { $exists: false } },
    { $set: { employees: [] } }
  );
  console.log(`Step 1 done: ${result.modifiedCount} shifts updated with empty employees array.`);
}

// ============================================================
// STEP 2 - Embed employee ObjectIds into shifts
// ============================================================

/**
 * Reads every assignment and pushes the employee's ObjectId into
 * the matching shift's employees array. Uses $addToSet to avoid
 * duplicates if the script is accidentally run more than once.
 * @returns {Promise<void>}
 */
async function embedEmployeesIntoShifts() {
  const db = await getDb();

  const assignments = await db.collection("assignments").find({}).toArray();

  let count = 0;
  let i = 0;
  while (i < assignments.length) {
    const assignment = assignments[i];

    // Look up the employee by the old employeeId string field
    const employee = await db.collection("employees").findOne({ employeeId: assignment.employeeId });
    if (!employee) {
      console.log(`  Warning: no employee found for employeeId ${assignment.employeeId}`);
      i++;
      continue;
    }

    // Look up the shift by the old shiftId string field
    const shift = await db.collection("shifts").findOne({ shiftId: assignment.shiftId });
    if (!shift) {
      console.log(`  Warning: no shift found for shiftId ${assignment.shiftId}`);
      i++;
      continue;
    }

    // Embed the employee ObjectId into the shift
    await db.collection("shifts").updateOne(
      { _id: shift._id },
      { $addToSet: { employees: employee._id } }
    );

    console.log(`  Linked employee ${assignment.employeeId} (${employee._id}) -> shift ${assignment.shiftId} (${shift._id})`);
    count++;
    i++;
  }

  console.log(`Step 2 done: ${count} assignments embedded into shifts.`);
}

// ============================================================
// STEP 3 - Remove old fields and drop assignments collection
// ============================================================

/**
 * Removes the old employeeId field from all employee documents.
 * @returns {Promise<void>}
 */
async function removeEmployeeIdField() {
  const db = await getDb();
  const result = await db.collection("employees").updateMany(
    {},
    { $unset: { employeeId: "" } }
  );
  console.log(`Step 3a done: employeeId field removed from ${result.modifiedCount} employee documents.`);
}

/**
 * Removes the old shiftId field from all shift documents.
 * @returns {Promise<void>}
 */
async function removeShiftIdField() {
  const db = await getDb();
  const result = await db.collection("shifts").updateMany(
    {},
    { $unset: { shiftId: "" } }
  );
  console.log(`Step 3b done: shiftId field removed from ${result.modifiedCount} shift documents.`);
}

/**
 * Drops the assignments collection entirely.
 * @returns {Promise<void>}
 */
async function dropAssignmentsCollection() {
  const db = await getDb();
  await db.collection("assignments").drop();
  console.log("Step 3c done: assignments collection dropped.");
}

// Alternatively, these can also be done directly in Compass using:
//   db.employees.updateMany({}, { $unset: { employeeId: "" } })
//   db.shifts.updateMany({}, { $unset: { shiftId: "" } })
//   db.assignments.drop()

// ============================================================
// MAIN - Run all steps in order
// ============================================================

/**
 * Runs the full migration from Assignment 3 schema to Assignment 4 schema.
 * Make sure to back up the database in Compass before running this!
 * @returns {Promise<void>}
 */
async function runMigration() {
  console.log("Starting database migration...");
  console.log("Make sure you have backed up the database before running this!\n");

  await addEmptyEmployeesArrayToShifts();
  await embedEmployeesIntoShifts();
  await removeEmployeeIdField();
  await removeShiftIdField();
  await dropAssignmentsCollection();

  console.log("\nMigration complete!");
  process.exit(0);
}

runMigration().catch((err) => {
  console.error("Migration failed:", err);
  process.exit(1);
});