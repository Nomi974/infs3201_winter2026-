# INFS3201 Assignment 4 - README

## Test User Credentials

Two test accounts have been created in the `users` collection in MongoDB:

| Username | Password  |
|----------|-----------|
| admin    | admin123  |
| user1    | pass1234  |

---

## Setting Up the Users Collection in MongoDB Compass

The users collection stores passwords as SHA-256 hashes (no salt required per assignment spec).

To generate the hash for a password, run this in a Node.js REPL:

```
node
> require('crypto').createHash('sha256').update('admin123').digest('hex')
> require('crypto').createHash('sha256').update('pass1234').digest('hex')
```

Then in Compass, create a `users` collection and insert two documents like:

```json
{ "username": "admin", "password": "<sha256 hash of admin123>" }
{ "username": "user1", "password": "<sha256 hash of pass1234>" }
```

---

## Running the App

1. Make sure your `.env` file has `MONGODB_URI` and `DB_NAME` set.
2. Run the database migration first (only needed once):
   ```
   node transform_db.js
   ```
3. Start the app:
   ```
   node app.js
   ```
4. Visit http://localhost:3000 and log in with one of the test accounts above.

---

## Session Behaviour

- Sessions expire after **5 minutes** of inactivity.
- Each page visit by a logged-in user resets the timer for another 5 minutes.
- No `express-session` library is used — sessions are managed with a custom
  in-memory store and a `Set-Cookie` header.

---

## GitHub Repository

Link included in D2L submission comments.
