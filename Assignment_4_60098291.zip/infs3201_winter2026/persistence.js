const { MongoClient, ObjectId } = require("mongodb");

const DB_NAME = "infs3201_winter2026";

let _db = null;

/**
 * Get database singleton.
 * @returns {Promise<import("mongodb").Db>}
 */
async function getDb() {
  if (_db) return _db;
  const uri = process.env.MONGODB_URI;
  if (!uri) throw new Error("Missing MONGODB_URI env var");
  const client = new MongoClient(uri);
  await client.connect();
  _db = client.db(DB_NAME);
  return _db;
}

/**
 * Insert a new employee into the employees collection.
 * @param {string} name
 * @param {string} phone
 * @returns {Promise<string>} the new employee's inserted _id as a string
 */
async function createEmployee(name, phone) {
  const db = await getDb();
  const result = await db.collection("employees").insertOne({ name, phone });
  return result.insertedId.toString();
}

/**
 * Get all employees.
 * @returns {Promise<Array<Object>>}
 */
async function getAllEmployees() {
  const db = await getDb();
  return await db.collection("employees").find({}).toArray();
}

/**
 * Get one employee by their ObjectId string.
 * @param {string} empId - 24-character hex ObjectId string from the URL
 * @returns {Promise<Object|null>}
 */
async function getEmployeeById(empId) {
  const db = await getDb();
  return await db.collection("employees").findOne({ _id: new ObjectId(empId) });
}

/**
 * Update employee name and phone by their ObjectId string.
 * @param {string} empId - 24-character hex ObjectId string
 * @param {string} name
 * @param {string} phone
 * @returns {Promise<boolean>} true if a document was matched
 */
async function updateEmployee(empId, name, phone) {
  const db = await getDb();
  const result = await db.collection("employees").updateOne(
    { _id: new ObjectId(empId) },
    { $set: { name: name, phone: phone } }
  );
  return result.matchedCount === 1;
}

/**
 * Get all shifts that contain a given employee ObjectId in their employees array.
 * Replaces the old getAssignmentsByEmployeeId + getShiftsByIds two-step lookup.
 * @param {ObjectId} empObjectId - already-converted ObjectId (not a string)
 * @returns {Promise<Array<Object>>}
 */
async function getShiftsByEmployeeId(empObjectId) {
  const db = await getDb();
  return await db.collection("shifts").find({ employees: empObjectId }).toArray();
}

/**
 * Get a user from the users collection by username.
 * Used for login authentication.
 * @param {string} username
 * @returns {Promise<Object|null>}
 */
async function getUserByUsername(username) {
  const db = await getDb();
  return await db.collection("users").findOne({ username: username });
}

/**
 * Insert a security log entry.
 * @param {Object} entry - { timestamp, username, url, method }
 * @returns {Promise<void>}
 */
async function insertSecurityLog(entry) {
  const db = await getDb();
  await db.collection("security_log").insertOne(entry);
}

module.exports = {
  createEmployee,
  getAllEmployees,
  getEmployeeById,
  updateEmployee,
  getShiftsByEmployeeId,
  getUserByUsername,
  insertSecurityLog
};
